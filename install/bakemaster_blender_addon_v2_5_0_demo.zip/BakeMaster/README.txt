# This file is included with the addon to note the user about the usage guide
# =============================================================================
#
# License information is outlined in the LICENSE file. If you didn't receive it,
# see <http://www.gnu.org/licenses/>.
#
# The installation guide can be read on the addon's Blender Market page
# (https://blendermarket.com/products/bakemaster) or Gumroad
# (https://kemplerart.gumroad.com/l/bakemaster).
#
# You can also get all the information in BakeMaster's online documentation
# (https://bakemaster-blender-addon.readthedocs.io/en/latest/), where all
# tutorials and usage explanations are listed as well.
#
# Join our Discord and ask any kind of question you've got raised
# (https://discord.gg/2ePzzzMBf4), or email the author
# (kirilstrezikozin@gmail.com) directly.
