<img src="https://raw.githubusercontent.com/KirilStrezikozin/BakeMaster-Blender-Addon/master/.github/images/teasers/bakemaster-addon-teaser-primary.png" alt="bakemaster-addon-teaser-primary" width="1280px"/>

<!--- Heading -->
<h1 id="page-top">
    <a href="#page-top">
        Welcome to <br />
        BakeMaster 2.5.2 Blender Add-on
    </a>
</h1>

<!-- Intro -->
BakeMaster is an add-on specified for baking various texture maps <br/>and created for Blender - an open-source 3D Computer graphics software. <br/>Along with its intuitive and convenient workflow baking process becomes a pleasure. <br/>Created from scratch for users who can't stand wasting time, <br />and yearn for most functionality and cutting-edge features.

<a href='https://bakemaster-blender-addon.readthedocs.io/en/2.5.2/'>
    <img src='https://readthedocs.org/projects/bakemaster-blender-addon/badge/?version=latest' alt='Documentation Status' />
</a>

---

Check out BakeMaster's product page on [Blender Market](https://blendermarket.com/products/bakemaster) or [Gumroad](https://kemplerart.gumroad.com/l/bakemaster)

> Join our [Discord](https://discord.gg/2ePzzzMBf4) Stay tuned for [Announcements](https://github.com/KirilStrezikozin/BakeMaster-Blender-Addon/discussions/5) ✅</span> <br>
